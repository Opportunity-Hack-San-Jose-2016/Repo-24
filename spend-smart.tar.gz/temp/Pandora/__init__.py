from pb_py import main as API

HOST = 'aiaas.pandorabots.com'
USER_KEY="9eeacc4aff1d792b1a53041ee45e45d0"
APP_ID="1409612826680"


def dry_run(input):
    response = API.talk(USER_KEY, APP_ID, HOST,'test420',input)
    # print response
    return response


if __name__ == '__main__':
    dry_run()
